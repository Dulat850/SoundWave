import { NavLink } from 'react-router';
import { Home, Users, ListMusic, Plus, Music } from 'lucide-react';

export function Sidebar() {
  const navItems = [
    { to: '/', icon: Home, label: 'Главная' },
    { to: '/artists', icon: Users, label: 'Артисты' },
    { to: '/playlists', icon: ListMusic, label: 'Плейлисты' },
    { to: '/add-track', icon: Plus, label: 'Добавить трек' },
  ];

  return (
    <aside className="w-64 bg-black/40 backdrop-blur-lg border-r border-white/10 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <Music className="w-8 h-8 text-purple-400" />
          <h1 className="text-xl font-bold">SoundWave</h1>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                    isActive
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-300 hover:bg-white/10 hover:text-white'
                  }`
                }
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}