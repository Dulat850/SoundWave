import { useState } from 'react';
import { Upload, Music, Check, AlertCircle } from 'lucide-react';

export function AddTrack() {
  const [formData, setFormData] = useState({
    title: '',
    artist: '',
    album: '',
    genre: '',
    duration: '',
    year: '',
  });
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors: string[] = [];
    
    if (!formData.title.trim()) newErrors.push('Название трека обязательно');
    if (!formData.artist.trim()) newErrors.push('Имя артиста обязательно');
    if (!formData.duration.trim()) newErrors.push('Продолжительность обязательна');
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    // Simulate track upload
    console.log('Uploading track:', formData);
    
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      // Reset form
      setFormData({
        title: '',
        artist: '',
        album: '',
        genre: '',
        duration: '',
        year: '',
      });
      setCoverPreview(null);
      setErrors([]);
    }, 2000);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Добавить трек</h1>
        <p className="text-gray-400">Загрузите новую музыку в библиотеку</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cover Upload */}
        <div className="lg:col-span-1">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <h3 className="font-semibold mb-4">Обложка</h3>
            
            <div className="relative aspect-square bg-white/5 rounded-lg border-2 border-dashed border-white/20 hover:border-purple-500 transition overflow-hidden group cursor-pointer">
              {coverPreview ? (
                <>
                  <img
                    src={coverPreview}
                    alt="Cover preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                    <Upload className="w-8 h-8" />
                  </div>
                </>
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <Music className="w-12 h-12 text-gray-500 mb-2" />
                  <p className="text-sm text-gray-400">Загрузить обложку</p>
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleCoverUpload}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </div>
            
            <p className="text-xs text-gray-500 mt-2">Рекомендуется 1:1, JPG или PNG</p>
          </div>
        </div>

        {/* Track Information Form */}
        <div className="lg:col-span-2">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <h3 className="font-semibold mb-6">Информация о треке</h3>

            {errors.length > 0 && (
              <div className="mb-6 bg-red-500/20 border border-red-500/50 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-200 mb-1">Ошибки валидации:</p>
                    <ul className="text-sm text-red-300 space-y-1">
                      {errors.map((error, index) => (
                        <li key={index}>• {error}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {showSuccess && (
              <div className="mb-6 bg-green-500/20 border border-green-500/50 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-400" />
                  <p className="text-green-200">Трек успешно добавлен!</p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium mb-2">
                    Название трека *
                  </label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-400"
                    placeholder="Название трека"
                  />
                </div>

                <div>
                  <label htmlFor="artist" className="block text-sm font-medium mb-2">
                    Артист *
                  </label>
                  <input
                    type="text"
                    id="artist"
                    name="artist"
                    value={formData.artist}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-400"
                    placeholder="Имя артиста"
                  />
                </div>

                <div>
                  <label htmlFor="album" className="block text-sm font-medium mb-2">
                    Альбом
                  </label>
                  <input
                    type="text"
                    id="album"
                    name="album"
                    value={formData.album}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-400"
                    placeholder="Название альбома"
                  />
                </div>

                <div>
                  <label htmlFor="genre" className="block text-sm font-medium mb-2">
                    Жанр
                  </label>
                  <select
                    id="genre"
                    name="genre"
                    value={formData.genre}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                  >
                    <option value="">Выберите жанр</option>
                    <option value="pop">Pop</option>
                    <option value="rock">Rock</option>
                    <option value="electronic">Electronic</option>
                    <option value="hiphop">Hip-Hop</option>
                    <option value="jazz">Jazz</option>
                    <option value="classical">Classical</option>
                    <option value="indie">Indie</option>
                    <option value="other">Другое</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="duration" className="block text-sm font-medium mb-2">
                    Продолжительность *
                  </label>
                  <input
                    type="text"
                    id="duration"
                    name="duration"
                    value={formData.duration}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-400"
                    placeholder="3:45"
                  />
                </div>

                <div>
                  <label htmlFor="year" className="block text-sm font-medium mb-2">
                    Год выпуска
                  </label>
                  <input
                    type="text"
                    id="year"
                    name="year"
                    value={formData.year}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-400"
                    placeholder="2026"
                  />
                </div>
              </div>

              {/* Audio File Upload */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Аудио файл
                </label>
                <div className="relative">
                  <div className="border-2 border-dashed border-white/20 hover:border-purple-500 rounded-lg p-8 text-center cursor-pointer transition">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-400 mb-1">
                      Перетащите файл или кликните для выбора
                    </p>
                    <p className="text-xs text-gray-500">MP3, WAV, FLAC до 50MB</p>
                    <input
                      type="file"
                      accept="audio/*"
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setFormData({
                      title: '',
                      artist: '',
                      album: '',
                      genre: '',
                      duration: '',
                      year: '',
                    });
                    setCoverPreview(null);
                    setErrors([]);
                  }}
                  className="flex-1 py-3 bg-white/10 hover:bg-white/15 rounded-lg transition"
                >
                  Сбросить
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition flex items-center justify-center gap-2"
                >
                  <Upload className="w-5 h-5" />
                  Добавить трек
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
