import { useState } from 'react';
import { Play, Music, Plus, Trash2 } from 'lucide-react';

interface Playlist {
  id: number;
  name: string;
  cover: string;
  trackCount: number;
  duration: string;
  tracks: {
    id: number;
    title: string;
    artist: string;
    duration: string;
  }[];
}

const mockPlaylists: Playlist[] = [
  {
    id: 1,
    name: 'Мой микс 2026',
    cover: 'https://images.unsplash.com/photo-1644855640845-ab57a047320e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGFsYnVtJTIwY292ZXJ8ZW58MXx8fHwxNzcwMDA0MjgxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 25,
    duration: '1ч 45мин',
    tracks: [
      { id: 1, title: 'Midnight Dreams', artist: 'Luna Wave', duration: '3:45' },
      { id: 2, title: 'Summer Vibes', artist: 'Sunset Band', duration: '4:12' },
      { id: 3, title: 'Electric Soul', artist: 'Neon Hearts', duration: '3:28' },
    ],
  },
  {
    id: 2,
    name: 'Тренировка',
    cover: 'https://images.unsplash.com/photo-1616663395403-2e0052b8e595?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW55bCUyMHJlY29yZCUyMGFsYnVtfGVufDF8fHx8MTc2OTk5ODgxNnww&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 30,
    duration: '2ч 10мин',
    tracks: [
      { id: 4, title: 'City Lights', artist: 'Urban Echo', duration: '5:03' },
      { id: 5, title: 'Energy Boost', artist: 'Power Sound', duration: '3:55' },
    ],
  },
  {
    id: 3,
    name: 'Расслабление',
    cover: 'https://images.unsplash.com/photo-1649956736509-f359d191bbcb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFkcGhvbmVzJTIwbXVzaWN8ZW58MXx8fHwxNzcwMDIxNDIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 18,
    duration: '1ч 20мин',
    tracks: [
      { id: 6, title: 'Calm Waters', artist: 'Peaceful Mind', duration: '4:30' },
      { id: 7, title: 'Zen Garden', artist: 'Nature Sounds', duration: '5:15' },
    ],
  },
  {
    id: 4,
    name: 'Вечеринка',
    cover: 'https://images.unsplash.com/photo-1740459057005-65f000db582f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25jZXJ0JTIwc3RhZ2UlMjBsaWdodHN8ZW58MXx8fHwxNzY5OTI4NDk1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 40,
    duration: '2ч 45мин',
    tracks: [
      { id: 8, title: 'Dance All Night', artist: 'DJ Pulse', duration: '3:40' },
      { id: 9, title: 'Party Anthem', artist: 'Beat Masters', duration: '4:25' },
    ],
  },
];

export function Playlists() {
  const [playlists, setPlaylists] = useState(mockPlaylists);
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');

  const handleCreatePlaylist = () => {
    if (newPlaylistName.trim()) {
      const newPlaylist: Playlist = {
        id: Date.now(),
        name: newPlaylistName,
        cover: 'https://images.unsplash.com/photo-1644855640845-ab57a047320e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGFsYnVtJTIwY292ZXJ8ZW58MXx8fHwxNzcwMDA0MjgxfDA&ixlib=rb-4.1.0&q=80&w=1080',
        trackCount: 0,
        duration: '0мин',
        tracks: [],
      };
      setPlaylists([...playlists, newPlaylist]);
      setNewPlaylistName('');
      setShowCreateModal(false);
    }
  };

  const handleDeletePlaylist = (playlistId: number) => {
    setPlaylists(playlists.filter((p) => p.id !== playlistId));
    if (selectedPlaylist?.id === playlistId) {
      setSelectedPlaylist(null);
    }
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Плейлисты</h1>
          <p className="text-gray-400">Ваши коллекции музыки</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Создать плейлист
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Playlists Grid */}
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {playlists.map((playlist) => (
              <div
                key={playlist.id}
                onClick={() => setSelectedPlaylist(playlist)}
                className={`bg-white/10 backdrop-blur-lg rounded-xl overflow-hidden cursor-pointer transition group ${
                  selectedPlaylist?.id === playlist.id
                    ? 'ring-2 ring-purple-500'
                    : 'hover:bg-white/15'
                }`}
              >
                <div className="relative">
                  <img
                    src={playlist.cover}
                    alt={playlist.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                    <button className="p-4 bg-purple-600 rounded-full">
                      <Play className="w-6 h-6" fill="white" />
                    </button>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{playlist.name}</h3>
                  <p className="text-sm text-gray-400">
                    {playlist.trackCount} треков · {playlist.duration}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Playlist Details */}
        <div className="lg:col-span-1">
          {selectedPlaylist ? (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 sticky top-8">
              <img
                src={selectedPlaylist.cover}
                alt={selectedPlaylist.name}
                className="w-full aspect-square rounded-lg object-cover mb-4 shadow-xl"
              />
              
              <h2 className="text-2xl font-bold mb-2">{selectedPlaylist.name}</h2>
              <p className="text-gray-400 mb-6">
                {selectedPlaylist.trackCount} треков · {selectedPlaylist.duration}
              </p>

              <div className="space-y-2 mb-6 max-h-64 overflow-y-auto">
                {selectedPlaylist.tracks.length > 0 ? (
                  selectedPlaylist.tracks.map((track, index) => (
                    <div
                      key={track.id}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/10 transition"
                    >
                      <span className="text-gray-400 w-6 text-sm">{index + 1}</span>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate text-sm">{track.title}</p>
                        <p className="text-xs text-gray-400 truncate">{track.artist}</p>
                      </div>
                      <span className="text-xs text-gray-400">{track.duration}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-gray-400 py-8">
                    Плейлист пуст. Добавьте треки!
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <button className="w-full py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition flex items-center justify-center gap-2">
                  <Play className="w-5 h-5" fill="white" />
                  Воспроизвести
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeletePlaylist(selectedPlaylist.id);
                  }}
                  className="w-full py-3 bg-red-600/20 hover:bg-red-600/30 border border-red-500/50 rounded-lg transition flex items-center justify-center gap-2 text-red-400"
                >
                  <Trash2 className="w-5 h-5" />
                  Удалить плейлист
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 h-64 flex items-center justify-center text-center">
              <div>
                <Music className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                <p className="text-gray-400">Выберите плейлист для просмотра треков</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Create Playlist Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-2xl p-6 max-w-md w-full">
            <h2 className="text-2xl font-bold mb-4">Создать плейлист</h2>
            <input
              type="text"
              value={newPlaylistName}
              onChange={(e) => setNewPlaylistName(e.target.value)}
              placeholder="Название плейлиста"
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-400 mb-6"
              autoFocus
            />
            <div className="flex gap-3">
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 py-3 bg-white/10 hover:bg-white/15 rounded-lg transition"
              >
                Отмена
              </button>
              <button
                onClick={handleCreatePlaylist}
                className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition"
              >
                Создать
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
