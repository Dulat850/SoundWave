import { useState } from 'react';
import { Play, Music2 } from 'lucide-react';

interface Artist {
  id: number;
  name: string;
  genre: string;
  image: string;
  trackCount: number;
  tracks: {
    id: number;
    title: string;
    duration: string;
  }[];
}

const mockArtists: Artist[] = [
  {
    id: 1,
    name: 'Luna Wave',
    genre: 'Electronic',
    image: 'https://images.unsplash.com/photo-1675859427928-fe41277572b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpY2lhbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc3MDAyMjQxMXww&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 12,
    tracks: [
      { id: 1, title: 'Midnight Dreams', duration: '3:45' },
      { id: 2, title: 'Starlight', duration: '4:20' },
      { id: 3, title: 'Ocean Waves', duration: '3:15' },
    ],
  },
  {
    id: 2,
    name: 'Sunset Band',
    genre: 'Indie Rock',
    image: 'https://images.unsplash.com/photo-1698793916022-7bb35b2122cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaW5nZXIlMjBwZXJmb3JtZXJ8ZW58MXx8fHwxNzcwMDI0NzU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 15,
    tracks: [
      { id: 4, title: 'Summer Vibes', duration: '4:12' },
      { id: 5, title: 'Golden Hour', duration: '3:58' },
      { id: 6, title: 'Beach Day', duration: '3:30' },
    ],
  },
  {
    id: 3,
    name: 'Neon Hearts',
    genre: 'Synth Pop',
    image: 'https://images.unsplash.com/photo-1762290264887-b8b1370a462d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaiUyMGFydGlzdHxlbnwxfHx8fDE3NzAwMjQ3NjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 18,
    tracks: [
      { id: 7, title: 'Electric Soul', duration: '3:28' },
      { id: 8, title: 'Neon Lights', duration: '4:05' },
      { id: 9, title: 'Digital Love', duration: '3:42' },
    ],
  },
  {
    id: 4,
    name: 'Urban Echo',
    genre: 'Hip Hop',
    image: 'https://images.unsplash.com/photo-1649956736509-f359d191bbcb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFkcGhvbmVzJTIwbXVzaWN8ZW58MXx8fHwxNzcwMDIxNDIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    trackCount: 20,
    tracks: [
      { id: 10, title: 'City Lights', duration: '5:03' },
      { id: 11, title: 'Street Dreams', duration: '4:15' },
      { id: 12, title: 'Urban Legend', duration: '3:55' },
    ],
  },
];

export function Artists() {
  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Артисты</h1>
        <p className="text-gray-400">Исследуйте любимых исполнителей</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Artists List */}
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockArtists.map((artist) => (
              <div
                key={artist.id}
                onClick={() => setSelectedArtist(artist)}
                className={`bg-white/10 backdrop-blur-lg rounded-xl p-4 cursor-pointer transition ${
                  selectedArtist?.id === artist.id
                    ? 'ring-2 ring-purple-500'
                    : 'hover:bg-white/15'
                }`}
              >
                <div className="flex items-center gap-4">
                  <img
                    src={artist.image}
                    alt={artist.name}
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{artist.name}</h3>
                    <p className="text-sm text-gray-400">{artist.genre}</p>
                    <p className="text-sm text-purple-400 mt-1">
                      {artist.trackCount} треков
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Artist Details */}
        <div className="lg:col-span-1">
          {selectedArtist ? (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 sticky top-8">
              <div className="text-center mb-6">
                <img
                  src={selectedArtist.image}
                  alt={selectedArtist.name}
                  className="w-32 h-32 rounded-full object-cover mx-auto mb-4 shadow-xl"
                />
                <h2 className="text-2xl font-bold mb-2">{selectedArtist.name}</h2>
                <p className="text-gray-400">{selectedArtist.genre}</p>
              </div>

              <div className="mb-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Music2 className="w-5 h-5" />
                  Популярные треки
                </h3>
                <div className="space-y-2">
                  {selectedArtist.tracks.map((track, index) => (
                    <div
                      key={track.id}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/10 transition group"
                    >
                      <span className="text-gray-400 w-6 text-sm">{index + 1}</span>
                      <button className="p-2 bg-purple-600 rounded-full opacity-0 group-hover:opacity-100 transition">
                        <Play className="w-3 h-3" fill="white" />
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{track.title}</p>
                      </div>
                      <span className="text-sm text-gray-400">{track.duration}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button className="w-full py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition flex items-center justify-center gap-2">
                <Play className="w-5 h-5" fill="white" />
                Воспроизвести все
              </button>
            </div>
          ) : (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 h-64 flex items-center justify-center text-center">
              <div>
                <Music2 className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                <p className="text-gray-400">Выберите артиста, чтобы увидеть его треки</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
