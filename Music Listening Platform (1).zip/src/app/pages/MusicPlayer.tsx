import { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Heart } from 'lucide-react';
import { useAuth } from '@/app/context/AuthContext';
import { useNavigate } from 'react-router';

interface Song {
  id: number;
  title: string;
  artist: string;
  duration: string;
  cover: string;
}

const mockSongs: Song[] = [
  {
    id: 1,
    title: 'Midnight Dreams',
    artist: 'Luna Wave',
    duration: '3:45',
    cover: 'https://images.unsplash.com/photo-1644855640845-ab57a047320e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGFsYnVtJTIwY292ZXJ8ZW58MXx8fHwxNzcwMDA0MjgxfDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 2,
    title: 'Summer Vibes',
    artist: 'Sunset Band',
    duration: '4:12',
    cover: 'https://images.unsplash.com/photo-1616663395403-2e0052b8e595?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW55bCUyMHJlY29yZCUyMGFsYnVtfGVufDF8fHx8MTc2OTk5ODgxNnww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 3,
    title: 'Electric Soul',
    artist: 'Neon Hearts',
    duration: '3:28',
    cover: 'https://images.unsplash.com/photo-1649956736509-f359d191bbcb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFkcGhvbmVzJTIwbXVzaWN8ZW58MXx8fHwxNzcwMDIxNDIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 4,
    title: 'City Lights',
    artist: 'Urban Echo',
    duration: '5:03',
    cover: 'https://images.unsplash.com/photo-1740459057005-65f000db582f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25jZXJ0JTIwc3RhZ2UlMjBsaWdodHN8ZW58MXx8fHwxNzY5OTI4NDk1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
];

export function MusicPlayer() {
  const [currentSong, setCurrentSong] = useState<Song>(mockSongs[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(70);
  const [likedSongs, setLikedSongs] = useState<Set<number>>(new Set());
  const progressInterval = useRef<NodeJS.Timeout | null>(null);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isPlaying) {
      progressInterval.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            handleNext();
            return 0;
          }
          return prev + 0.5;
        });
      }, 200);
    } else {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    }

    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    };
  }, [isPlaying]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    const currentIndex = mockSongs.findIndex((song) => song.id === currentSong.id);
    const nextIndex = (currentIndex + 1) % mockSongs.length;
    setCurrentSong(mockSongs[nextIndex]);
    setProgress(0);
  };

  const handlePrevious = () => {
    const currentIndex = mockSongs.findIndex((song) => song.id === currentSong.id);
    const prevIndex = currentIndex === 0 ? mockSongs.length - 1 : currentIndex - 1;
    setCurrentSong(mockSongs[prevIndex]);
    setProgress(0);
  };

  const handleSongClick = (song: Song) => {
    setCurrentSong(song);
    setIsPlaying(true);
    setProgress(0);
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProgress(Number(e.target.value));
  };

  const toggleLike = (songId: number) => {
    setLikedSongs((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(songId)) {
        newSet.delete(songId);
      } else {
        newSet.add(songId);
      }
      return newSet;
    });
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Главная</h1>
        <p className="text-gray-400">Слушайте любимую музыку</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Player */}
        <div className="lg:col-span-2">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8">
            {/* Album Cover */}
            <div className="aspect-square rounded-xl overflow-hidden mb-6 shadow-2xl">
              <img
                src={currentSong.cover}
                alt={currentSong.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Song Info */}
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold mb-2">{currentSong.title}</h2>
              <p className="text-gray-300">{currentSong.artist}</p>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <input
                type="range"
                min="0"
                max="100"
                value={progress}
                onChange={handleProgressChange}
                className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-purple-500 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-2">
                <span>{Math.floor((progress / 100) * 225)}s</span>
                <span>{currentSong.duration}</span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-6 mb-6">
              <button
                onClick={handlePrevious}
                className="p-3 hover:bg-white/10 rounded-full transition"
              >
                <SkipBack className="w-6 h-6" />
              </button>
              <button
                onClick={handlePlayPause}
                className="p-5 bg-purple-600 hover:bg-purple-700 rounded-full transition shadow-lg"
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8" fill="white" />
                ) : (
                  <Play className="w-8 h-8" fill="white" />
                )}
              </button>
              <button
                onClick={handleNext}
                className="p-3 hover:bg-white/10 rounded-full transition"
              >
                <SkipForward className="w-6 h-6" />
              </button>
            </div>

            {/* Volume Control */}
            <div className="flex items-center gap-3">
              <Volume2 className="w-5 h-5 text-gray-400" />
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="flex-1 h-2 bg-white/20 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:cursor-pointer"
              />
              <span className="text-sm text-gray-400 w-10">{volume}%</span>
            </div>
          </div>
        </div>

        {/* Playlist */}
        <div className="lg:col-span-1">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
            <h3 className="text-xl font-bold mb-4">Плейлист</h3>
            <div className="space-y-3">
              {mockSongs.map((song) => (
                <div
                  key={song.id}
                  onClick={() => handleSongClick(song)}
                  className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition ${
                    currentSong.id === song.id
                      ? 'bg-purple-600/50'
                      : 'hover:bg-white/10'
                  }`}
                >
                  <img
                    src={song.cover}
                    alt={song.title}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{song.title}</p>
                    <p className="text-sm text-gray-400 truncate">{song.artist}</p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleLike(song.id);
                    }}
                    className="p-2 hover:bg-white/10 rounded-full transition"
                  >
                    <Heart
                      className={`w-5 h-5 ${
                        likedSongs.has(song.id)
                          ? 'fill-red-500 text-red-500'
                          : 'text-gray-400'
                      }`}
                    />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}