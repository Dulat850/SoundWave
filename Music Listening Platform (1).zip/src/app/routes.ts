import { createBrowserRouter } from 'react-router';
import { Login } from '@/app/pages/Login';
import { SignUp } from '@/app/pages/SignUp';
import { MusicPlayer } from '@/app/pages/MusicPlayer';
import { Artists } from '@/app/pages/Artists';
import { Playlists } from '@/app/pages/Playlists';
import { AddTrack } from '@/app/pages/AddTrack';
import { ProtectedRoute } from '@/app/components/ProtectedRoute';
import { Layout } from '@/app/components/Layout';

export const router = createBrowserRouter([
  {
    path: '/login',
    Component: Login,
  },
  {
    path: '/signup',
    Component: SignUp,
  },
  {
    path: '/',
    Component: ProtectedRoute,
    children: [
      {
        Component: Layout,
        children: [
          {
            index: true,
            Component: MusicPlayer,
          },
          {
            path: 'artists',
            Component: Artists,
          },
          {
            path: 'playlists',
            Component: Playlists,
          },
          {
            path: 'add-track',
            Component: AddTrack,
          },
        ],
      },
    ],
  },
]);